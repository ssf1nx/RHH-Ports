# Zelda: Dungeons of Infinity — Optimizations

Patches against the v1.1.6 VM build of *Zelda: Dungeons of Infinity*, targeting ARM64 Linux retro handhelds. The original GM Studio source is not available; all changes are GML patches that get re-imported into `data.win` via UndertaleModTool.

## What's optimized

| Area | Change | Measured impact |
|---|---|---|
| **Boot data load** | Per-class binary preformat (`__BinaryFormat`) replacing the 45 MB JSON parse | Peak INIT RAM 1784 -> 1138 MB |
| **Room generation** | Lazy dungeon transforms (compute on demand instead of pre-baking 8 copies per template) | Peak 1138 -> 732 MB |
| **Room generation** | All-class preload at INIT | Per-dungeon parse hitches eliminated (35 s -> ~2 s on first dungeon, ~0 s subsequent) |
| **Dungeon RAM** | Defaults-stripped binary (`convert_data_to_binary.py`) | `data_r` 16.1 MB → 13.4 MB on disk; equivalent in-RAM tree shrink |
| **Hash caching** | `variable_get_hash("X")` → cached `global.Hash_X` in every render path + generation hot loop | Eliminates ~115 hash recomputes per generation + many per render frame |
| **Per-frame collision** | `WallCollision()` — persistent temp list (no `ds_list_create`/`destroy` churn), hoisted `object_get_parent`, early exit on zero velocity | 60-80 active instances: 22.9 ms -> 11.6 ms frame time (~44 fps -> ~86 fps) |
| **Misc** | Bugfix for `oEnemy_Zol` resurrection reading from the unloaded section pool | No more segfault on room re-entry |

## Status (as of this writing)

- **Boots cleanly on RG353V (ROCKNIX, 1.9 GB RAM).** First boot ~38s of class-parse during the loading splash; subsequent dungeons load in ~2s with no mid-game freezes.
- **Steady-state RSS ~950 MB.** Plateaus after a few dungeon entries; not a leak (validated across 3-4 dungeon types).
- **Thermal**: stable at 80-83 °C with the launcher-side 1.4 GHz CPU cap + 600 MHz GPU cap.

## Build

```bash
python src/tools/expand_patches.py
"UndertaleModCli.exe" \
    load data.win \
    --scripts "tools/apply_patches.csx" \
    --output game.droid \
    --verbose
```