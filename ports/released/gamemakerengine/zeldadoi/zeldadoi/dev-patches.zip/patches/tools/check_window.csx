using System;
using UndertaleModLib;

EnsureDataLoaded();

Console.WriteLine($"DefaultWindow: {Data.GeneralInfo.DefaultWindowWidth}x{Data.GeneralInfo.DefaultWindowHeight}");
Console.WriteLine($"Display name: {Data.GeneralInfo.DisplayName?.Content}");
Console.WriteLine($"GMS Version: {Data.GeneralInfo.Major}.{Data.GeneralInfo.Minor}.{Data.GeneralInfo.Release}.{Data.GeneralInfo.Build}");
Console.WriteLine($"FileName: {Data.GeneralInfo.FileName?.Content}");
Console.WriteLine($"Bytecode version: {Data.GeneralInfo.BytecodeVersion}");
Console.WriteLine($"Total scripts: {Data.Scripts.Count}");
Console.WriteLine($"Total code entries: {Data.Code.Count}");
Console.WriteLine($"Total strings: {Data.Strings.Count}");
