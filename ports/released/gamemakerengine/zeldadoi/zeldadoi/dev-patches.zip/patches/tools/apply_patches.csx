// UTMT CLI script — bulk-apply every .gml in src/patches/ to the loaded data file.
//
// Invocation:
//   UndertaleModCli.exe load <data.win> --scripts apply_patches.csx \
//       --output <out_dir> --verbose
//
// What this does:
//   - For each .gml file in src/patches/, queue a code replacement against the
//     asset whose name matches the filename (sans extension), e.g.:
//         gml_GlobalScript___HashConstants.gml -> gml_GlobalScript___HashConstants
//         gml_Object_oInit_Draw_77.gml         -> oInit's Draw event 77
//   - AutoCreateAssets = true means new global scripts (__HashConstants,
//     __BinaryFormat, __DryRun) are created on the fly. Existing assets are
//     overwritten.
//   - The import group runs in one atomic batch — failures roll back.
//
// Constraints / decisions:
//   - No GUI prompts (CLI safe).
//   - Hardcoded patches path resolved from script location to avoid surprises.

using System;
using System.IO;
using System.Linq;
using UndertaleModLib.Compiler;

EnsureDataLoaded();

// Patches are stored as unified diffs against exportedcode/ (or as full .gml
// for files new to this build). Run src/tools/expand_patches.py to produce
// build/patches/<name>.gml ready for QueueReplace below.
string scriptDir   = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
string patchesDir  = @"D:\GitHub\SourceProjects\ZeldaDungeonsOfInfinity\build\patches";

if (!Directory.Exists(patchesDir))
    throw new Exception($"Patches directory not found: {patchesDir}");

string[] files = Directory.GetFiles(patchesDir, "*.gml")
                          .OrderBy(f => f)
                          .ToArray();
if (files.Length == 0)
    throw new Exception($"No .gml files found under {patchesDir}");

Console.WriteLine($"[apply_patches] {files.Length} patch files in {patchesDir}");

CodeImportGroup importGroup = new(Data)
{
    AutoCreateAssets = true,
};

int newCount = 0, replacedCount = 0;
foreach (string file in files)
{
    string name = Path.GetFileNameWithoutExtension(file);
    string code = File.ReadAllText(file);

    // Existence check is for logging only — QueueReplace handles both cases
    // when AutoCreateAssets is true.
    bool exists = Data.Code?.ByName(name) != null;
    if (exists)
    {
        Console.WriteLine($"  REPLACE  {name}");
        replacedCount++;
    }
    else
    {
        Console.WriteLine($"  CREATE   {name}");
        newCount++;
    }

    importGroup.QueueReplace(name, code);
}

Console.WriteLine($"[apply_patches] Importing... ({replacedCount} replaced, {newCount} new)");
importGroup.Import();
Console.WriteLine("[apply_patches] Done.");

// FPS fix: native-render pipeline (matches Isles of Sea and Sky's approach).
// Original DOI has View=400x225 but Port=1600x900 (4x internal upscale),
// Room_Dungeon also has View[1]=256x224 -> 1024x896 port at (288,0).  All
// the rendering happens at 4x scale into a 1600x900 application_surface,
// then 1:1 blitted to a 1600x900 window.  We collapse all three:
//   - Every view's Port = its View size (1:1, no upscale)
//   - DefaultWindow = 400x225 (matches the largest view port)
//   - gmloader/SDL handles the WINDOW -> DEVICE stretch outside the render
//     path (the same scaling it already does for any GM game)
int viewsFixed = 0;
foreach (UndertaleModLib.Models.UndertaleRoom room in Data.Rooms)
{
    if (room.Views == null) continue;
    for (int i = 0; i < room.Views.Count; i++)
    {
        var v = room.Views[i];
        if (v == null) continue;
        if (!v.Enabled) continue;
        if (v.ViewWidth <= 0 || v.ViewHeight <= 0) continue;

        if (v.PortWidth >= v.ViewWidth * 4 && v.PortHeight >= v.ViewHeight * 4)
        {
            v.PortWidth  = v.PortWidth  / 4;
            v.PortHeight = v.PortHeight / 4;
            v.PortX      = v.PortX / 4;
            v.PortY      = v.PortY / 4;
            viewsFixed++;
        }
    }
}
// DefaultWindow must match the view-port size or gmloader hits its
// mallinfo-wrap bug during chunk init and segfaults.  Both 1600x900 and
// 1200x675 crash with this combo; only window == ports works.  So integer
// scaling has to be arranged at runtime (window_set_size after gmloader
// init) or via gmloader.json's filter setting (device-side nearest filter).
Data.GeneralInfo.DefaultWindowWidth  = 400;
Data.GeneralInfo.DefaultWindowHeight = 225;
Console.WriteLine($"[apply_patches] Native-render: {viewsFixed} views scaled to 1:1, window set to 400x225 (matches ports - integer scaling deferred to runtime)");

// Cap each room's Speed at 60. The game's source had room_speed values
// tuned for Windows desktop (some 80-110+ FPS in profile traces); on ARM
// handhelds the extra frames are pure heat (60Hz panel can't show >60 fps
// anyway). Capping here at build time bypasses the GML compiler entirely
// since game_set_speed got UTMT-demoted (function not in BuiltinList.cs).
int roomsCapped = 0;
foreach (UndertaleModLib.Models.UndertaleRoom room in Data.Rooms)
{
    if (room.Speed > 60)
    {
        room.Speed = 60;
        roomsCapped++;
    }
}
Console.WriteLine($"[apply_patches] FPS cap: {roomsCapped} rooms had Speed > 60, capped to 60");

// Shader fix: shd_CRT's GLSL ES fragment source has a strict-spec compile
// error (module-scope non-constant initializer) that crashes shader compile
// on PowerVR / Mali. Patch the source in-place.
foreach (UndertaleModLib.Models.UndertaleShader s in Data.Shaders)
{
    if (s?.Name?.Content != "shd_CRT") continue;
    string frag = s.GLSL_ES_Fragment?.Content;
    if (frag == null) break;

    bool changed = false;

    const string oldPrec = "precision mediump float;";
    const string newPrec =
        "#ifdef GL_FRAGMENT_PRECISION_HIGH\n" +
        "precision highp float;\n" +
        "#else\n" +
        "precision mediump float;\n" +
        "#endif";
    if (frag.Contains(oldPrec) && !frag.Contains("GL_FRAGMENT_PRECISION_HIGH"))
    {
        frag = frag.Replace(oldPrec, newPrec);
        changed = true;
    }

    const string oldGlobal = "vec2 aspect = uni_crt_sizes.xy / uni_crt_sizes.x;";
    const string newGlobal = "// (moved into border_corners to satisfy strict GLSL ES)";
    if (frag.Contains(oldGlobal))
    {
        frag = frag.Replace(oldGlobal, newGlobal);
        changed = true;
    }

    // Insert the aspect calc right after the border_corners opening brace.
    // Match on a substring tolerant to whitespace/newlines between the brace
    // and the next statement.
    const string borderFnSig = "float border_corners(vec2 UV) {";
    const string borderFnInsert = "float border_corners(vec2 UV) {\n  vec2 aspect = uni_crt_sizes.xy / uni_crt_sizes.x;";
    if (frag.Contains(borderFnSig) && !frag.Contains("vec2 aspect = uni_crt_sizes.xy / uni_crt_sizes.x;\n  UV"))
    {
        // Replace only the first occurrence by finding and splicing.
        int idx = frag.IndexOf(borderFnSig);
        frag = frag.Substring(0, idx) + borderFnInsert + frag.Substring(idx + borderFnSig.Length);
        changed = true;
    }

    if (changed)
    {
        s.GLSL_ES_Fragment.Content = frag;
        Console.WriteLine("[apply_patches] shd_CRT: fragment patched for strict GLSL ES (precision + global init)");
    }
    break;
}
