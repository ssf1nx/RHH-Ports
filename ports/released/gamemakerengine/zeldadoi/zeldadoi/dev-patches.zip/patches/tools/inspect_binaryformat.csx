using System;
using UndertaleModLib;
using UndertaleModLib.Models;

EnsureDataLoaded();

string[] targets = { "gml_GlobalScript___BinaryFormat" };

foreach (string name in targets)
{
    var code = Data.Code?.ByName(name);
    if (code == null) { Console.WriteLine($"NOT FOUND: {name}"); continue; }
    Console.WriteLine($"== {name} (length={code.Length})");
    string dis = code.Disassemble(Data.Variables, Data.CodeLocals?.ByName(name));
    Console.WriteLine(dis);
}
