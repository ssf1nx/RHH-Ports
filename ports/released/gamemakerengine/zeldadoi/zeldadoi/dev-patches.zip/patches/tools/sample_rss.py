"""Cache-accumulation validator: samples the game's OS-level working-set memory
at 1 Hz while you play through the game, logs to CSV, and prints a summary.

Why this exists: the lazy dungeon transform (#3) generates a fresh struct copy
per dungeon load. Dungeon_DestroyLevel is supposed to null out the prior
level's refs before the next Dungeon_InitLevel runs, but that's a theoretical
claim until we watch RSS over time. If peak working set is flat-ish as you
move between dungeons -> reclaim works, no accumulation. If it grows -> leak.

Usage
-----
    python sample_rss.py                    # launches the game, samples until exit
    python sample_rss.py --attach           # samples an already-running game
    python sample_rss.py --interval 0.5     # finer sampling (default 1.0s)
    python sample_rss.py --out my.csv       # custom output path

Output
------
CSV columns: t_sec, working_set_mb, peak_so_far_mb
Plus a summary printed at exit:
    peak, max single-second growth, total samples, runtime
"""

from __future__ import annotations

import argparse
import csv
import os
import subprocess
import sys
import time
import ctypes
from ctypes import wintypes

REPO    = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
EXE     = os.path.join(REPO, "prebuilt", "Dungeons of Infinity.exe")
EXENAME = "Dungeons of Infinity.exe"


# -- Win32 helpers --------------------------------------------------------

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ           = 0x0010

class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb",                          wintypes.DWORD),
        ("PageFaultCount",              wintypes.DWORD),
        ("PeakWorkingSetSize",          ctypes.c_size_t),
        ("WorkingSetSize",              ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage",     ctypes.c_size_t),
        ("QuotaPagedPoolUsage",         ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage",  ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage",      ctypes.c_size_t),
        ("PagefileUsage",               ctypes.c_size_t),
        ("PeakPagefileUsage",           ctypes.c_size_t),
    ]


def open_handle(pid: int):
    h = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
    if not h:
        raise OSError(f"OpenProcess({pid}) failed: error {ctypes.GetLastError()}")
    return h


def sample(handle) -> tuple[int, int]:
    """Returns (working_set_size, peak_working_set_size) in bytes."""
    pmc = PROCESS_MEMORY_COUNTERS()
    pmc.cb = ctypes.sizeof(pmc)
    if not ctypes.windll.psapi.GetProcessMemoryInfo(handle, ctypes.byref(pmc), pmc.cb):
        return 0, 0
    return pmc.WorkingSetSize, pmc.PeakWorkingSetSize


def find_pid_by_name(name: str) -> int | None:
    """Find first PID matching an executable name via tasklist."""
    out = subprocess.check_output(["tasklist", "/FI", f"imagename eq {name}", "/FO", "csv", "/NH"],
                                  text=True)
    for line in out.splitlines():
        if name.lower() in line.lower():
            parts = [p.strip('"') for p in line.split(",")]
            if len(parts) >= 2 and parts[1].isdigit():
                return int(parts[1])
    return None


# -- Driver ---------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--attach",   action="store_true",
                    help="Sample an already-running game instead of launching one")
    ap.add_argument("--interval", type=float, default=1.0,
                    help="Sample interval in seconds (default 1.0)")
    ap.add_argument("--out",      default=None,
                    help="Output CSV path (default: rss_<pid>.csv)")
    args = ap.parse_args()

    if args.attach:
        pid = find_pid_by_name(EXENAME)
        if not pid:
            print(f"no running {EXENAME} found", file=sys.stderr)
            return 1
        proc = None
        print(f"attached to pid={pid}", flush=True)
    else:
        if not os.path.exists(EXE):
            print(f"missing exe: {EXE}", file=sys.stderr)
            return 1
        proc = subprocess.Popen([EXE], cwd=os.path.dirname(EXE))
        pid = proc.pid
        # Game needs a moment to actually start the process for memory queries.
        time.sleep(1.5)
        print(f"launched pid={pid}", flush=True)

    handle = open_handle(pid)
    out_path = args.out or os.path.join(REPO, f"rss_{pid}.csv")

    samples: list[tuple[float, int, int]] = []
    start = time.time()
    peak  = 0

    try:
        while True:
            try:
                ws, _ = sample(handle)
            except OSError:
                break
            if ws == 0:
                # process exited
                break
            t = time.time() - start
            if ws > peak:
                peak = ws
            samples.append((t, ws, peak))

            # Live progress (overwriting one line):
            sys.stdout.write(
                f"\r  t={t:6.1f}s  rss={ws/1024/1024:8.2f} MB  peak={peak/1024/1024:8.2f} MB    "
            )
            sys.stdout.flush()

            if proc is not None and proc.poll() is not None:
                break

            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\n  interrupted")

    print()

    # Write CSV.
    with open(out_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["t_sec", "working_set_mb", "peak_so_far_mb"])
        for t, ws, p in samples:
            w.writerow([f"{t:.2f}", f"{ws/1024/1024:.2f}", f"{p/1024/1024:.2f}"])

    # Summary.
    if not samples:
        print("no samples recorded", file=sys.stderr)
        return 1

    ws_values = [s[1] for s in samples]
    max_growth_per_sec = max(0, max(
        (b - a) for a, b in zip(ws_values, ws_values[1:])
    ) if len(ws_values) > 1 else 0)

    print(f"saved {len(samples)} samples to {out_path}")
    print(f"  runtime:        {samples[-1][0]:.1f} s")
    print(f"  start rss:      {samples[0][1]/1024/1024:.2f} MB")
    print(f"  end rss:        {samples[-1][1]/1024/1024:.2f} MB")
    print(f"  peak working:   {peak/1024/1024:.2f} MB")
    print(f"  max +1s growth: {max_growth_per_sec/1024/1024:.2f} MB")

    # Cache-accumulation heuristic: if end - start > 200 MB AND peak == end,
    # working set has trended upward without releasing. Flag for inspection.
    end_minus_start = samples[-1][1] - samples[0][1]
    if end_minus_start > 200 * 1024 * 1024 and samples[-1][1] >= peak * 0.99:
        print()
        print("  [WARN] end RSS is significantly higher than start AND near peak.")
        print("         Possible cache accumulation - inspect CSV across dungeon")
        print("         transitions to see if free-then-grow pattern is missing.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
