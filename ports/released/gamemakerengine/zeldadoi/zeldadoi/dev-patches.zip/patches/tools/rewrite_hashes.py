"""Optimization #4: rewrite inline variable_get_hash("X") calls to cached
global.Hash_X reads.

Reads from ../../exportedcode/ and writes to ../patches/. Skips third-party
Input library files (we cache their hashes defensively in HashConstants but
do not modify the library itself).

Re-runnable: idempotent for files we own (a second pass finds zero matches).
"""

import os
import re
import sys

ROOT     = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC      = os.path.join(ROOT, "exportedcode")
DST      = os.path.join(ROOT, "src", "patches")

# Skip these — Juju Input library, owned upstream.
INPUT_LIB_PREFIXES = (
    "gml_GlobalScript_input_",
    "gml_GlobalScript___input_",
)

# Files we are explicitly opting in. Anything else under exportedcode/ is
# left alone for now — extending the scope later is just appending here.
TARGETS = [
    "gml_GlobalScript___RoomTemplates.gml",
    "gml_GlobalScript___Dungeon.gml",
    "gml_GlobalScript___Dungeon_Draw_Carpets.gml",
    "gml_GlobalScript___Dungeon_Draw_FloorObjs.gml",
    "gml_GlobalScript___Dungeon_Draw_SpecialObjs.gml",
    "gml_GlobalScript___Dungeon_Draw_SpecialObjs_Forced.gml",
    "gml_GlobalScript___Dungeon_Draw_Walls.gml",
    "gml_GlobalScript___Transformations.gml",
    "gml_GlobalScript___Enemies.gml",
    "gml_GlobalScript___Error.gml",
    "gml_Object_oEnemy_Zol_Create_0.gml",
    "gml_Object_oLink_Step_0.gml",
]

CALL_RE = re.compile(r'variable_get_hash\("([A-Za-z_][A-Za-z0-9_]*)"\)')


def rewrite(text: str) -> tuple[str, int]:
    """Replace variable_get_hash("X") with global.Hash_X. Returns (new_text, count)."""
    count = 0

    def sub(m: re.Match) -> str:
        nonlocal count
        count += 1
        return f"global.Hash_{m.group(1)}"

    return CALL_RE.sub(sub, text), count


def main() -> int:
    if not os.path.isdir(SRC):
        print(f"missing source: {SRC}", file=sys.stderr)
        return 1
    os.makedirs(DST, exist_ok=True)

    total_in  = 0
    total_out = 0
    skipped: list[str] = []

    for name in TARGETS:
        # Guard: never rewrite Input library files even if listed by mistake.
        if name.startswith(INPUT_LIB_PREFIXES):
            skipped.append(name)
            continue

        dst_path = os.path.join(DST, name)
        src_path = os.path.join(SRC, name)

        # Operate in-place on the patches tree so manual edits (binary loader
        # swap, future structural patches) are preserved on re-run. If the
        # patch file doesn't exist yet, seed it from exportedcode/.
        if os.path.isfile(dst_path):
            read_from = dst_path
            origin = "patches"
        elif os.path.isfile(src_path):
            read_from = src_path
            origin = "exported"
        else:
            print(f"  MISSING  {name}", file=sys.stderr)
            continue

        with open(read_from, encoding="utf-8") as fh:
            original = fh.read()
        before = len(CALL_RE.findall(original))
        new, replaced = rewrite(original)
        after = len(CALL_RE.findall(new))

        with open(dst_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(new)

        total_in  += before
        total_out += replaced
        marker = "OK " if after == 0 else "!! "
        print(f"  {marker}  [{origin:8s}] {name:55s}  {before:3d} -> {after:3d}  "
              f"({replaced} rewritten)")

    print()
    print(f"total rewritten: {total_out} (of {total_in} found)")
    if skipped:
        print(f"skipped (input lib): {len(skipped)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
