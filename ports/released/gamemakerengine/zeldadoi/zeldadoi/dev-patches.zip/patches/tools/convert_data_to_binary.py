"""Optimization #1: convert data_r / data_d JSON to a compact binary format.

Motivation
----------
GM's current loader peaks at ~3x the file size in RAM:
  buffer_load -> 45 MB buffer
  buffer_read(... buffer_string) -> 45 MB string copy
  json_parse -> parser temp tree + final struct tree
The peak spike is what OOM-crashes sub-2GB ARM handhelds on the title screen.

This format avoids all of that. We:
  - Intern every key and string value into one table (only ~1k unique strings).
  - Pack integer-valued numbers into s8/s16/s32 (60% of data_r numbers fit in s8).
  - Stream-read into a struct tree using buffer_read primitives.
  - Never materialize a 45 MB intermediate string.

Format (v1)
-----------
  Header
    magic    4 bytes : "ZBIN"
    version  u8      : 1

  String table
    count    u32     : number of interned strings
    strings  count x (null-terminated UTF-8 bytes)

  Root value
    tagged value (recursive)

  Tagged value
    tag u8
    payload by tag:
      0 NULL      -> none
      1 FALSE     -> none
      2 TRUE      -> none
      3 INT8      -> s8
      4 INT16     -> s16  (little-endian)
      5 INT32     -> s32  (little-endian)
      6 FLOAT64   -> f64  (little-endian; integers that don't fit s32 also use this)
      7 STRING    -> u16  (index into string table)
      8 ARRAY     -> u32 count, count x tagged value
      9 OBJECT    -> u32 count, count x (u16 key_index, tagged value)

Notes
-----
  - Endianness is little-endian throughout to match GM's default buffer reads.
  - The GM loader's job is reduced to recursive descent over fixed-width fields.
  - Round-trip verifier proves byte-for-byte equivalence vs the source JSON
    (modulo numeric type — JSON 0.0 becomes int 0; GM treats them identically).

Usage
-----
  python convert_data_to_binary.py            # convert + verify both files
  python convert_data_to_binary.py --no-verify
"""

from __future__ import annotations

import argparse
import io
import json
import os
import struct
import sys

ROOT      = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA_DIR  = os.path.join(ROOT, "prebuilt", "data")
FILES     = ("data_r", "data_d")

MAGIC     = b"ZBIN"
VERSION   = 1

# ---- Field stripping (defaults-aware) -----------------------------------
#
# Tiled exports include several fields whose default values aren't read at
# runtime. Stripping them shrinks the binary AND cuts the recursive
# BinaryFormat_ReadValue call count proportionally (the dominant load cost).
#
# Safety analysis (verified against src/patches/ usage):
#   visible : never read on template data. Always strip.
#   name="" : runtime reads via struct_get_from_hash and compares with `==`
#             against non-empty strings. undefined and "" both fail.  Safe.
#   type="" : NOT STRIPPED. Many tile-draw code paths do `real(ObjType)`
#             after guarding with `if (ObjType != "")`. Empty-string fails
#             that guard; `undefined` (stripped) passes it, then real()
#             on undefined crashes. See Dungeon_Draw_SpecialObjs_Forced:62.
#   id      : top-level template id IS read (DoorWarpTemplateID match in
#             Dungeon_Draw_SpecialObjs_Forced). Sub-object ids are not read
#             anywhere on the template data. Strip from sub-objects only,
#             keep at top level. Depth-aware via _strip_template.
#
# Not stripped (would change runtime behaviour):
#   rotation=0  : tried; UTMT's compiler mis-parsed the GML wrappers
#                 needed at the read sites (compiled `Obj.rotation = X`
#                 as a method call). Reverted - keeping rotation in the
#                 binary.
#   properties=[] : zero occurrences in the data (every Tiled object has
#                 at least one property), so stripping would save nothing.

def _strip_template(tmpl):
    """Strip safe defaults from one top-level room template (in-place).
    Keeps the template's own `id`; strips id from every nested dict."""
    def walk(node, is_top):
        if isinstance(node, dict):
            for k in ("visible",):
                if k in node:
                    del node[k]
            if node.get("name") == "":
                del node["name"]
            if not is_top and "id" in node:
                del node["id"]
            for v in node.values():
                walk(v, False)
        elif isinstance(node, list):
            for e in node:
                walk(e, False)
    walk(tmpl, True)
    return tmpl


def strip_tree_data_r(tree):
    """tree shape: [Class][SubClass][TemplateIndex] = template_dict."""
    for klass in tree:
        if not isinstance(klass, list): continue
        for sub in klass:
            if not isinstance(sub, list): continue
            for tmpl in sub:
                if isinstance(tmpl, dict):
                    _strip_template(tmpl)
    return tree


def _count_values(x) -> int:
    """Count total tagged-value emissions (one per primitive/container)."""
    if isinstance(x, dict):
        n = 1
        for v in x.values():
            n += _count_values(v)
        return n
    if isinstance(x, list):
        n = 1
        for e in x:
            n += _count_values(e)
        return n
    return 1


def strip_tree_data_d(tree):
    """data_d shape: [DungeonIndex] = dungeon_dict (no template-style id
    semantics; treat every dict as 'not top-level' for id stripping is fine
    since data_d code doesn't compare .id to anything)."""
    def walk(node, is_top_dungeon):
        if isinstance(node, dict):
            for k in ("visible",):
                if k in node: del node[k]
            if node.get("name") == "": del node["name"]
            # data_d: no top-level id reads identified; strip everywhere.
            if "id" in node:
                del node["id"]
            for v in node.values():
                walk(v, False)
        elif isinstance(node, list):
            for e in node:
                walk(e, False)
    walk(tree, True)
    return tree

TAG_NULL    = 0
TAG_FALSE   = 1
TAG_TRUE    = 2
TAG_INT8    = 3
TAG_INT16   = 4
TAG_INT32   = 5
TAG_FLOAT64 = 6
TAG_STRING  = 7
TAG_ARRAY   = 8
TAG_OBJECT  = 9

S8_MIN, S8_MAX   = -(1 << 7),  (1 << 7) - 1
S16_MIN, S16_MAX = -(1 << 15), (1 << 15) - 1
S32_MIN, S32_MAX = -(1 << 31), (1 << 31) - 1


# ---- JSON loader ---------------------------------------------------------

def load_gm_json(path: str):
    """GM writes a trailing NUL byte after the JSON document — strip it."""
    with open(path, "rb") as f:
        raw = f.read()
    return json.loads(raw.rstrip(b"\x00").decode("utf-8"))


# ---- String table --------------------------------------------------------

def collect_strings(root) -> list[str]:
    """Walk the tree, collect every distinct string (keys + values), order by
    descending frequency so common strings get the smallest indices (purely
    cosmetic — all indices are u16 anyway)."""
    freq: dict[str, int] = {}

    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                freq[k] = freq.get(k, 0) + 1
                walk(v)
        elif isinstance(x, list):
            for e in x:
                walk(e)
        elif isinstance(x, str):
            freq[x] = freq.get(x, 0) + 1

    walk(root)
    ordered = sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))
    return [s for s, _ in ordered]


# ---- Encoder -------------------------------------------------------------

class Encoder:
    def __init__(self, strings: list[str]):
        self.strings = strings
        self.index = {s: i for i, s in enumerate(strings)}
        if len(strings) > 0xFFFF:
            raise ValueError(f"string table exceeds u16: {len(strings)}")
        self.buf = io.BytesIO()

    def write_header(self) -> None:
        self.buf.write(MAGIC)
        self.buf.write(struct.pack("<B", VERSION))

    def write_string_table(self) -> None:
        self.buf.write(struct.pack("<I", len(self.strings)))
        for s in self.strings:
            data = s.encode("utf-8")
            if b"\x00" in data:
                raise ValueError(f"string contains NUL: {s!r}")
            self.buf.write(data)
            self.buf.write(b"\x00")

    def write_value(self, x) -> None:
        b = self.buf
        if x is None:
            b.write(struct.pack("<B", TAG_NULL))
        elif x is True:
            b.write(struct.pack("<B", TAG_TRUE))
        elif x is False:
            b.write(struct.pack("<B", TAG_FALSE))
        elif isinstance(x, str):
            b.write(struct.pack("<BH", TAG_STRING, self.index[x]))
        elif isinstance(x, (int, float)):
            self._write_number(x)
        elif isinstance(x, list):
            b.write(struct.pack("<BI", TAG_ARRAY, len(x)))
            for e in x:
                self.write_value(e)
        elif isinstance(x, dict):
            b.write(struct.pack("<BI", TAG_OBJECT, len(x)))
            for k, v in x.items():
                b.write(struct.pack("<H", self.index[k]))
                self.write_value(v)
        else:
            raise TypeError(f"unsupported value type {type(x).__name__}: {x!r}")

    def _write_number(self, x) -> None:
        b = self.buf
        # Promote integer-valued floats to int — GM treats them identically and
        # we save 6 bytes each (f64 vs s8/s16). Genuine fractions stay f64.
        if isinstance(x, float):
            if x.is_integer() and S32_MIN <= int(x) <= S32_MAX:
                x = int(x)
            else:
                b.write(struct.pack("<Bd", TAG_FLOAT64, x))
                return
        # int (or promoted)
        if S8_MIN <= x <= S8_MAX:
            b.write(struct.pack("<Bb", TAG_INT8, x))
        elif S16_MIN <= x <= S16_MAX:
            b.write(struct.pack("<Bh", TAG_INT16, x))
        elif S32_MIN <= x <= S32_MAX:
            b.write(struct.pack("<Bi", TAG_INT32, x))
        else:
            b.write(struct.pack("<Bd", TAG_FLOAT64, float(x)))

    def getvalue(self) -> bytes:
        return self.buf.getvalue()


# ---- Decoder (for round-trip verification) ------------------------------

class Decoder:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def read(self, n: int) -> bytes:
        out = self.data[self.pos:self.pos + n]
        if len(out) != n:
            raise EOFError(f"want {n} bytes at {self.pos}, got {len(out)}")
        self.pos += n
        return out

    def read_struct(self, fmt: str):
        size = struct.calcsize(fmt)
        return struct.unpack(fmt, self.read(size))

    def read_header(self) -> None:
        if self.read(4) != MAGIC:
            raise ValueError("bad magic")
        v, = self.read_struct("<B")
        if v != VERSION:
            raise ValueError(f"bad version {v}")

    def read_string_table(self) -> list[str]:
        count, = self.read_struct("<I")
        out = []
        for _ in range(count):
            start = self.pos
            end = self.data.index(b"\x00", start)
            out.append(self.data[start:end].decode("utf-8"))
            self.pos = end + 1
        return out

    def read_value(self, strs: list[str]):
        tag, = self.read_struct("<B")
        if tag == TAG_NULL:    return None
        if tag == TAG_FALSE:   return False
        if tag == TAG_TRUE:    return True
        if tag == TAG_INT8:    return self.read_struct("<b")[0]
        if tag == TAG_INT16:   return self.read_struct("<h")[0]
        if tag == TAG_INT32:   return self.read_struct("<i")[0]
        if tag == TAG_FLOAT64: return self.read_struct("<d")[0]
        if tag == TAG_STRING:  return strs[self.read_struct("<H")[0]]
        if tag == TAG_ARRAY:
            n, = self.read_struct("<I")
            return [self.read_value(strs) for _ in range(n)]
        if tag == TAG_OBJECT:
            n, = self.read_struct("<I")
            out = {}
            for _ in range(n):
                ki, = self.read_struct("<H")
                out[strs[ki]] = self.read_value(strs)
            return out
        raise ValueError(f"bad tag {tag} at {self.pos - 1}")


def decode(data: bytes):
    d = Decoder(data)
    d.read_header()
    strs = d.read_string_table()
    root = d.read_value(strs)
    if d.pos != len(data):
        raise ValueError(f"trailing bytes: {len(data) - d.pos}")
    return root


# ---- Round-trip equivalence ---------------------------------------------

def equivalent(a, b) -> tuple[bool, str]:
    """Loose equality: JSON 1.0 and binary-decoded int 1 are equivalent."""
    if isinstance(a, dict) and isinstance(b, dict):
        if a.keys() != b.keys():
            return False, f"key mismatch: {set(a) ^ set(b)}"
        for k in a:
            ok, why = equivalent(a[k], b[k])
            if not ok:
                return False, f"at .{k}: {why}"
        return True, ""
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return False, f"length {len(a)} vs {len(b)}"
        for i, (x, y) in enumerate(zip(a, b)):
            ok, why = equivalent(x, y)
            if not ok:
                return False, f"at [{i}]: {why}"
        return True, ""
    if isinstance(a, bool) or isinstance(b, bool):
        return (a is b), f"bool {a} vs {b}"
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return (float(a) == float(b)), f"num {a} vs {b}"
    return (a == b), f"{a!r} vs {b!r}"


# ---- Driver -------------------------------------------------------------

def convert(name: str, *, verify: bool) -> None:
    src = os.path.join(DATA_DIR, name)
    dst = os.path.join(DATA_DIR, name + ".bin")
    print(f"[{name}] loading JSON ...", flush=True)
    tree = load_gm_json(src)

    if name == "data_r":
        before = _count_values(tree)
        strip_tree_data_r(tree)
        after = _count_values(tree)
        print(f"[{name}] stripped defaults: {before:,} -> {after:,} values "
              f"({100*after/before:.1f}%)")
    elif name == "data_d":
        before = _count_values(tree)
        strip_tree_data_d(tree)
        after = _count_values(tree)
        print(f"[{name}] stripped defaults: {before:,} -> {after:,} values "
              f"({100*after/before:.1f}%)")

    print(f"[{name}] interning strings ...", flush=True)
    strings = collect_strings(tree)
    print(f"[{name}]   {len(strings)} unique strings")

    print(f"[{name}] encoding ...", flush=True)
    enc = Encoder(strings)
    enc.write_header()
    enc.write_string_table()
    enc.write_value(tree)
    out = enc.getvalue()

    with open(dst, "wb") as f:
        f.write(out)

    src_size = os.path.getsize(src)
    print(f"[{name}] {src_size:>11,} bytes JSON  ->  {len(out):>11,} bytes bin  "
          f"({100 * len(out) / src_size:.1f}%)")

    if verify:
        print(f"[{name}] verifying round-trip ...", flush=True)
        decoded = decode(out)
        ok, why = equivalent(tree, decoded)
        if not ok:
            print(f"[{name}] FAIL: {why}", file=sys.stderr)
            raise SystemExit(2)
        print(f"[{name}] OK (round-trip equivalent)")


# ---- Per-class split (optimization #5 lazy loader) ----------------------
#
# data_r is split into:
#   data_r_index.bin   - header + per-class/subclass counts (sub-KB)
#   data_r_<c>.bin     - one file per class, each a self-contained ZBIN tree
#                        of [subclass][template_index] = template_struct
#
# The GM-side loader (RoomTemplates_LoadIndex / RoomTemplates_LoadClass)
# reads the index at INIT to populate Templates_Room_Count without
# materializing any templates, then lazy-loads per-class files in
# RoomTemplates_Pick when a class is first needed for a dungeon.

INDEX_MAGIC = b"ZBRI"
INDEX_VERSION = 1


def convert_split(name: str, *, verify: bool) -> None:
    """Split a top-level [class][subclass][template] tree into per-class
    binary files plus an index. Each class file is a normal ZBIN tree whose
    root is the [subclass][template] array for that class."""
    src = os.path.join(DATA_DIR, name)
    print(f"[{name}-split] loading JSON ...", flush=True)
    tree = load_gm_json(src)

    if name == "data_r":
        before = _count_values(tree)
        strip_tree_data_r(tree)
        after = _count_values(tree)
        print(f"[{name}-split] stripped defaults: {before:,} -> {after:,} "
              f"values ({100*after/before:.1f}%)")

    if not isinstance(tree, list):
        raise SystemExit(f"{name}: expected top-level array, got {type(tree).__name__}")
    n_classes = len(tree)
    if n_classes > 255:
        raise SystemExit(f"{name}: too many classes for u8 ({n_classes})")

    # Write index file: counts per class/subclass.
    idx = io.BytesIO()
    idx.write(INDEX_MAGIC)
    idx.write(struct.pack("<BB", INDEX_VERSION, n_classes))
    for c, klass in enumerate(tree):
        if not isinstance(klass, list):
            raise SystemExit(f"{name}: class {c} not an array (got {type(klass).__name__})")
        n_subs = len(klass)
        if n_subs > 255:
            raise SystemExit(f"{name}: class {c} has too many subclasses ({n_subs})")
        idx.write(struct.pack("<B", n_subs))
        for s, sub in enumerate(klass):
            if not isinstance(sub, list):
                raise SystemExit(f"{name}: class {c} subclass {s} not an array")
            idx.write(struct.pack("<I", len(sub)))

    index_path = os.path.join(DATA_DIR, name + "_index.bin")
    with open(index_path, "wb") as f:
        f.write(idx.getvalue())
    print(f"[{name}-split] wrote {index_path} ({idx.tell()} bytes)")

    # Write one ZBIN file per class. Each is independent (own string table).
    total_out = 0
    for c, klass in enumerate(tree):
        cls_strings = collect_strings(klass)
        enc = Encoder(cls_strings)
        enc.write_header()
        enc.write_string_table()
        enc.write_value(klass)
        out = enc.getvalue()
        cls_path = os.path.join(DATA_DIR, f"{name}_{c}.bin")
        with open(cls_path, "wb") as f:
            f.write(out)
        total_out += len(out)
        templates = sum(len(s) for s in klass if isinstance(s, list))
        print(f"[{name}-split]   class {c}: {templates:4d} templates, "
              f"{len(cls_strings):4d} strings, {len(out):>11,} bytes -> {cls_path}")

        if verify:
            decoded = decode(out)
            ok, why = equivalent(klass, decoded)
            if not ok:
                print(f"[{name}-split] class {c} FAIL: {why}", file=sys.stderr)
                raise SystemExit(2)

    src_size = os.path.getsize(src)
    print(f"[{name}-split] {src_size:>11,} bytes JSON  ->  "
          f"{total_out + idx.tell():>11,} bytes total bin  "
          f"({100 * (total_out + idx.tell()) / src_size:.1f}%)")
    if verify:
        print(f"[{name}-split] OK (per-class round-trip equivalent)")


# ---- Optimization #7: skeleton/Sections split --------------------------
#
# Each template's `Sections` field is 84% of class-0 mass. Within a section,
# `Zones` is small (a list of rectangles, read by the picker) while
# `Enemies`/`Pots`/etc. are heavy (read only after the pick succeeds, when
# the chosen template is being instantiated).
#
# Split layout (per class):
#   data_r_<c>_skel.bin  ZBIN tree of [subclass][template] where each
#                        template keeps its full top-level fields AND its
#                        Sections array, but each section element is
#                        replaced by {Zones, _sect_off, _sect_len} - the
#                        heavy per-section fields (Enemies, Pots, ...) are
#                        moved out.
#   data_r_<c>_sect.bin  ZBSE format: magic + version + string table +
#                        concatenated per-section blobs. Each blob starts
#                        with a u32 length prefix so the GML loader can
#                        bounds-check before reading.
#
# Runtime:
#   - Picker reads top-level fields and Sections[i].Zones during its try
#     loop - both live in the skel, no materialization in the hot path.
#   - On accept (StructCopy succeeded), GML calls MaterializeSection on the
#     two sections the picker is about to transform (_MainSectionID and
#     Section_ID, possibly the same). MaterializeSection seeks to _sect_off
#     in the open sect buffer, validates the u32 length matches _sect_len,
#     decodes one section worth of heavy fields, and merges them into the
#     section struct in NewRoomTemplate.
#   - Sect buffer opens on the first pick of a class and closes when that
#     class's last pick lands (eager-unload, same hook as Optimization #5).
#
# Why length-prefixed blobs: the prior attempt (CLAUDE.md "Skeleton/Sections
# schema split") OOM-died with uordblks=1.08 GB at INIT/menu - a classic
# parser-reads-garbage-and-allocates-gigabyte-array signature, which is
# what happens if any _sect_off is wrong by even one byte. The length
# prefix lets MaterializeSection reject obviously bad seeks (length >
# MAX_SECTION_BYTES) before BinaryFormat_ReadValue starts allocating.

SECT_MAGIC = b"ZBSE"
SECT_VERSION = 1
SECT_OFF_KEY = "_sect_off"     # absolute byte offset of this section's
                               # length prefix in the sect file
SECT_LEN_KEY = "_sect_len"     # value-bytes after the length prefix
MAX_SECTION_BYTES = 200_000    # runtime bounds-check threshold


def _split_template_sections(klass):
    """Split a class's templates into (skel_klass, sect_payload_bytes).

    skel_klass: parallel structure to klass, with each template's `Sections`
    array kept BUT each section element rewritten as
      {Zones, _sect_off, _sect_len}
    where Zones is the section's original Zones field (used by the picker's
    inner loop) and the off/len pair locates the rest of the section's
    fields in the sect payload.

    sect_payload_bytes: ZBSE header + sect string table + concatenated
    [u32 length, encoded {section minus Zones}] blobs.

    Empty templates (no Sections array): Sections stays []. No sect entries.
    Section with no heavy fields (just Zones): writes an empty {} blob -
    materialization is a no-op."""
    # Collect strings from heavy section data (everything BUT Zones) so the
    # sect file's own string table is independent of the skel file's.
    sect_strings_freq: dict[str, int] = {}
    def walk_heavy(x):
        if isinstance(x, dict):
            for k, v in x.items():
                sect_strings_freq[k] = sect_strings_freq.get(k, 0) + 1
                walk_heavy(v)
        elif isinstance(x, list):
            for e in x: walk_heavy(e)
        elif isinstance(x, str):
            sect_strings_freq[x] = sect_strings_freq.get(x, 0) + 1
    for sub in klass:
        for t in sub:
            for section in t.get("Sections", []):
                heavy = {k: v for k, v in section.items() if k != "Zones"}
                walk_heavy(heavy)
    sect_strings = [s for s, _ in sorted(sect_strings_freq.items(),
                                          key=lambda kv: (-kv[1], kv[0]))]

    # Write sect header + string table to a buffer.
    sect = io.BytesIO()
    sect.write(SECT_MAGIC)
    sect.write(struct.pack("<B", SECT_VERSION))
    sect.write(struct.pack("<I", len(sect_strings)))
    for s in sect_strings:
        data = s.encode("utf-8")
        if b"\x00" in data:
            raise ValueError(f"section string contains NUL: {s!r}")
        sect.write(data); sect.write(b"\x00")

    # Encode each section's heavy fields. Reuse Encoder's buf so writes append.
    sect_encoder = Encoder(sect_strings)
    sect_encoder.buf = sect

    skel_klass = []
    for sub in klass:
        sub_skel = []
        for t in sub:
            t_skel = {k: v for k, v in t.items() if k != "Sections"}
            sections = t.get("Sections", [])
            skel_sections = []
            for section in sections:
                heavy = {k: v for k, v in section.items() if k != "Zones"}
                # Reserve length prefix, encode value, backfill length.
                len_offset = sect.tell()
                sect.write(b"\x00\x00\x00\x00")
                data_start = sect.tell()
                sect_encoder.write_value(heavy)
                data_end = sect.tell()
                blob_len = data_end - data_start
                if blob_len > MAX_SECTION_BYTES:
                    raise ValueError(
                        f"section blob {blob_len} bytes exceeds runtime cap "
                        f"{MAX_SECTION_BYTES} - bump MAX_SECTION_BYTES in both "
                        f"convert_data_to_binary.py and BinaryFormat.gml")
                sect.seek(len_offset)
                sect.write(struct.pack("<I", blob_len))
                sect.seek(data_end)
                skel_sections.append({
                    "Zones":      section.get("Zones", []),
                    SECT_OFF_KEY: len_offset,
                    SECT_LEN_KEY: blob_len,
                })
            t_skel["Sections"] = skel_sections
            sub_skel.append(t_skel)
        skel_klass.append(sub_skel)

    return skel_klass, sect.getvalue()


def convert_split_skelsect(name: str, *, verify: bool) -> None:
    """Split data_r per class AND per template into skel + sect files.
    Cuts the resident class-0 footprint from ~70 MB to ~15 MB and the
    castle-entry parse from ~35 s to ~5 s + per-pick (~3 s)."""
    if name != "data_r":
        # Only data_r has the Sections-dominant structure worth splitting.
        return convert_split(name, verify=verify)

    src = os.path.join(DATA_DIR, name)
    print(f"[{name}-skelsect] loading JSON ...", flush=True)
    tree = load_gm_json(src)

    before = _count_values(tree)
    strip_tree_data_r(tree)
    after = _count_values(tree)
    print(f"[{name}-skelsect] stripped defaults: {before:,} -> {after:,} "
          f"values ({100*after/before:.1f}%)")

    n_classes = len(tree)
    if n_classes > 255:
        raise SystemExit(f"too many classes for u8: {n_classes}")

    # Index file (unchanged format - just per-class/subclass counts).
    idx = io.BytesIO()
    idx.write(INDEX_MAGIC)
    idx.write(struct.pack("<BB", INDEX_VERSION, n_classes))
    for c, klass in enumerate(tree):
        n_subs = len(klass)
        if n_subs > 255:
            raise SystemExit(f"class {c}: too many subclasses ({n_subs})")
        idx.write(struct.pack("<B", n_subs))
        for sub in klass:
            idx.write(struct.pack("<I", len(sub)))
    index_path = os.path.join(DATA_DIR, name + "_index.bin")
    with open(index_path, "wb") as f:
        f.write(idx.getvalue())
    print(f"[{name}-skelsect] wrote {index_path} ({idx.tell()} bytes)")

    total_skel = 0
    total_sect = 0
    for c, klass in enumerate(tree):
        skel_klass, sect_bytes = _split_template_sections(klass)

        # Write skel as standard ZBIN with its own string table.
        skel_strings = collect_strings(skel_klass)
        enc = Encoder(skel_strings)
        enc.write_header()
        enc.write_string_table()
        enc.write_value(skel_klass)
        skel_bytes = enc.getvalue()

        skel_path = os.path.join(DATA_DIR, f"{name}_{c}_skel.bin")
        sect_path = os.path.join(DATA_DIR, f"{name}_{c}_sect.bin")
        with open(skel_path, "wb") as f: f.write(skel_bytes)
        with open(sect_path, "wb") as f: f.write(sect_bytes)
        total_skel += len(skel_bytes)
        total_sect += len(sect_bytes)
        templates = sum(len(s) for s in klass if isinstance(s, list))
        print(f"[{name}-skelsect]  class {c}: {templates:4d} templates, "
              f"skel {len(skel_bytes):>10,}b, sect {len(sect_bytes):>10,}b")

        if verify:
            decoded_skel = decode(skel_bytes)
            ok, why = equivalent(skel_klass, decoded_skel)
            if not ok:
                print(f"[{name}-skelsect] class {c} skel FAIL: {why}", file=sys.stderr)
                raise SystemExit(2)
            # Spot-verify sect decode: for each template, for each section,
            # seek to its _sect_off in the sect bytes, read the length
            # prefix, decode the heavy fields, and verify (Zones from skel +
            # heavy from sect) reconstructs the original section.
            d = Decoder(sect_bytes)
            if d.read(4) != SECT_MAGIC:
                raise SystemExit(f"sect magic mismatch class {c}")
            d.read_struct("<B")  # version
            sect_strs = d.read_string_table()
            sect_strs_end = d.pos
            for sub_idx, sub in enumerate(klass):
                for t_idx, t in enumerate(sub):
                    skel_t = skel_klass[sub_idx][t_idx]
                    expected_sections = t.get("Sections", [])
                    skel_sections = skel_t["Sections"]
                    if len(skel_sections) != len(expected_sections):
                        print(f"FAIL class {c} sub {sub_idx} t {t_idx}: "
                              f"skel has {len(skel_sections)} sections, "
                              f"source has {len(expected_sections)}",
                              file=sys.stderr)
                        raise SystemExit(2)
                    for s_idx, (skel_s, src_s) in enumerate(zip(skel_sections, expected_sections)):
                        # Zones must round-trip exactly.
                        ok, why = equivalent(skel_s["Zones"], src_s.get("Zones", []))
                        if not ok:
                            print(f"FAIL class {c} sub {sub_idx} t {t_idx} "
                                  f"sec {s_idx} Zones: {why}", file=sys.stderr)
                            raise SystemExit(2)
                        # Heavy fields must reconstruct via _sect_off.
                        off = skel_s[SECT_OFF_KEY]
                        expected_len = skel_s[SECT_LEN_KEY]
                        d.pos = off
                        actual_len, = d.read_struct("<I")
                        if actual_len != expected_len:
                            print(f"FAIL class {c} sub {sub_idx} t {t_idx} "
                                  f"sec {s_idx}: sect prefix says {actual_len} "
                                  f"bytes, skel says {expected_len}",
                                  file=sys.stderr)
                            raise SystemExit(2)
                        heavy = d.read_value(sect_strs)
                        expected_heavy = {k: v for k, v in src_s.items() if k != "Zones"}
                        ok, why = equivalent(expected_heavy, heavy)
                        if not ok:
                            print(f"FAIL class {c} sub {sub_idx} t {t_idx} "
                                  f"sec {s_idx} heavy: {why}", file=sys.stderr)
                            raise SystemExit(2)

    src_size = os.path.getsize(src)
    print(f"[{name}-skelsect] {src_size:>11,} bytes JSON -> "
          f"skel total {total_skel:>10,} + sect total {total_sect:>10,} "
          f"({100 * (total_skel + total_sect) / src_size:.1f}%)")
    if verify:
        print(f"[{name}-skelsect] OK (round-trip verified)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-verify", action="store_true")
    ap.add_argument("--only", help="single file basename (data_r or data_d)")
    ap.add_argument("--split", action="store_true",
                    help="for data_r, emit per-class files (data_r_<c>.bin "
                         "+ data_r_index.bin) for the lazy class loader. "
                         "data_d is always emitted monolithically.")
    ap.add_argument("--skelsect", action="store_true",
                    help="for data_r, emit per-class skel+sect files "
                         "(data_r_<c>_skel.bin + data_r_<c>_sect.bin) "
                         "for the lazy-template-Sections loader. "
                         "Supersedes --split for data_r.")
    args = ap.parse_args()

    targets = [args.only] if args.only else list(FILES)
    for name in targets:
        if args.skelsect and name == "data_r":
            convert_split_skelsect(name, verify=not args.no_verify)
        elif args.split and name == "data_r":
            convert_split(name, verify=not args.no_verify)
        else:
            convert(name, verify=not args.no_verify)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
