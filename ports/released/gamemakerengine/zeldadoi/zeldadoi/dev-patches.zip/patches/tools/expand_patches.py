"""Expand src/patches/ into build/patches/ for apply_patches.csx to consume.

Each `<name>.gml.diff` is applied to `exportedcode/<name>.gml` (the upstream
baseline) and written to `build/patches/<name>.gml`. Files new to this build
(scripts that don't exist upstream) are diffed against /dev/null - the
expander starts from an empty file and applies the additions.

Run before invoking UndertaleModCli.exe with apply_patches.csx.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXPORTED = ROOT / "exportedcode"
PATCHES = ROOT / "src" / "patches"
OUT = ROOT / "build" / "patches"


def apply_diff(orig: Path | None, diff: Path, out: Path) -> None:
    """Copy orig (or seed empty) -> out, then apply diff via GNU patch.
    orig=None handles diffs against /dev/null for files new to this build."""
    out.parent.mkdir(parents=True, exist_ok=True)
    if orig is not None:
        shutil.copy(orig, out)
    else:
        out.write_bytes(b"")
    with diff.open("rb") as df:
        result = subprocess.run(
            ["patch", "-p0", "--no-backup-if-mismatch", "--silent", str(out)],
            stdin=df,
            capture_output=True,
        )
    if result.returncode != 0:
        sys.stderr.write(f"FAIL applying {diff.name}:\n")
        sys.stderr.write(result.stdout.decode("utf-8", errors="replace"))
        sys.stderr.write(result.stderr.decode("utf-8", errors="replace"))
        raise SystemExit(2)


def main() -> int:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)

    n_diff = 0
    n_full = 0
    for f in sorted(PATCHES.iterdir()):
        if f.is_dir():
            continue
        name = f.name
        if name.endswith(".gml.diff"):
            gml_name = name[: -len(".diff")]
            orig: Path | None = EXPORTED / gml_name
            assert orig is not None
            if not orig.exists():
                orig = None  # new file: diff applies against /dev/null
            apply_diff(orig, f, OUT / gml_name)
            n_diff += 1
        # ignore other files (README, etc.)

    print(f"[expand_patches] {n_diff} diffs applied -> {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
