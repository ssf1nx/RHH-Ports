using System;
using UndertaleModLib;
using UndertaleModLib.Models;

EnsureDataLoaded();

Console.WriteLine($"== Rooms ({Data.Rooms.Count}) ==");
int shown = 0;
foreach (var r in Data.Rooms)
{
    if (r.Views == null || r.Views.Count == 0) continue;
    var v = r.Views[0];
    if (v == null) continue;
    Console.WriteLine($"  {r.Name.Content}: View0 enabled={v.Enabled} view={v.ViewWidth}x{v.ViewHeight} port={v.PortWidth}x{v.PortHeight}");
    if (++shown >= 5) break;
}

// Search for any code referencing application_surface or window setup
Console.WriteLine($"\n== Code refs (string-search in raw strings) ==");
foreach (var s in Data.Strings)
{
    string c = s.Content;
    if (c == null) continue;
    if (c.Contains("application_surface_draw_enable") ||
        c.Contains("surface_resize") ||
        c.Contains("display_set_gui_size") ||
        c.Contains("draw_surface_stretched"))
    {
        Console.WriteLine($"  string: {c}");
    }
}

Console.WriteLine($"\n== Game window ==");
Console.WriteLine($"  DefaultWindowWidth = {Data.GeneralInfo.DefaultWindowWidth}");
Console.WriteLine($"  DefaultWindowHeight = {Data.GeneralInfo.DefaultWindowHeight}");
