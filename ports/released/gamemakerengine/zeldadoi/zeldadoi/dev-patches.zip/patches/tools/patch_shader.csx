// Patch shd_CRT's GLSL ES fragment source to fix the strict-spec compile
// errors that fail on PowerVR/Mali GPUs:
//   1. Module-scope `vec2 aspect = uni_crt_sizes.xy / uni_crt_sizes.x;`
//      violates the GLSL ES rule "globals declared with no storage qualifier
//      must be initialized with a constant expression."  Move the
//      computation into border_corners() (the only consumer).
//   2. `precision mediump float;` can cause visible banding/distortion on
//      the radial-distortion + scanline math.  Bump to `highp` when the
//      driver supports it; fall back to mediump otherwise.

using System;
using UndertaleModLib;
using UndertaleModLib.Models;

EnsureDataLoaded();

UndertaleShader crt = null;
foreach (var s in Data.Shaders)
{
    if (s?.Name?.Content == "shd_CRT") { crt = s; break; }
}
if (crt == null)
{
    Console.WriteLine("[patch_shader] shd_CRT not found, skipping");
    return;
}

string frag = crt.GLSL_ES_Fragment?.Content;
if (frag == null)
{
    Console.WriteLine("[patch_shader] shd_CRT.GLSL_ES_Fragment is null, skipping");
    return;
}

bool changed = false;

// 1. Precision: prefer highp when supported, fall back to mediump.
const string oldPrec = "precision mediump float;";
const string newPrec =
    "#ifdef GL_FRAGMENT_PRECISION_HIGH\n" +
    "precision highp float;\n" +
    "#else\n" +
    "precision mediump float;\n" +
    "#endif";
if (frag.Contains(oldPrec) && !frag.Contains("GL_FRAGMENT_PRECISION_HIGH"))
{
    frag = frag.Replace(oldPrec, newPrec);
    changed = true;
    Console.WriteLine("[patch_shader] shd_CRT: precision -> highp (fallback mediump)");
}

// 2. Move the non-const global initializer out of module scope.
//    The global `aspect` is only used inside border_corners(); compute it
//    locally there.
const string oldGlobal = "vec2 aspect = uni_crt_sizes.xy / uni_crt_sizes.x;";
const string newGlobal = "// (moved inline into border_corners() to satisfy strict GLSL ES global-init rule)";
if (frag.Contains(oldGlobal))
{
    frag = frag.Replace(oldGlobal, newGlobal);
    changed = true;
    Console.WriteLine("[patch_shader] shd_CRT: removed module-scope `vec2 aspect = ...`");
}

const string oldBorderHead = "float border_corners(vec2 UV) {\n  UV = UV - 0.5 + 0.5;";
const string newBorderHead = "float border_corners(vec2 UV) {\n  vec2 aspect = uni_crt_sizes.xy / uni_crt_sizes.x;\n  UV = UV - 0.5 + 0.5;";
if (frag.Contains(oldBorderHead) && !frag.Contains("vec2 aspect = uni_crt_sizes.xy / uni_crt_sizes.x;\n  UV = UV - 0.5"))
{
    frag = frag.Replace(oldBorderHead, newBorderHead);
    changed = true;
    Console.WriteLine("[patch_shader] shd_CRT: added local aspect calc inside border_corners()");
}

if (changed)
{
    crt.GLSL_ES_Fragment.Content = frag;
    Console.WriteLine("[patch_shader] shd_CRT updated.");
}
else
{
    Console.WriteLine("[patch_shader] shd_CRT already patched, nothing to do.");
}
