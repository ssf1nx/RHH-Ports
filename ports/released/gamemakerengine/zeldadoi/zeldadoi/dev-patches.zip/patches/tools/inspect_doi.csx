using System;
using UndertaleModLib;
using UndertaleModLib.Models;

EnsureDataLoaded();

Console.WriteLine($"== Window ==");
Console.WriteLine($"  DefaultWindow = {Data.GeneralInfo.DefaultWindowWidth}x{Data.GeneralInfo.DefaultWindowHeight}");

Console.WriteLine($"\n== Rooms - ALL views ==");
foreach (var r in Data.Rooms)
{
    if (r.Views == null || r.Views.Count == 0) continue;
    Console.WriteLine($"  {r.Name.Content}:");
    for (int i = 0; i < r.Views.Count; i++)
    {
        var v = r.Views[i];
        if (v == null) continue;
        if (!v.Enabled) continue;
        Console.WriteLine($"    View[{i}]: view={v.ViewWidth}x{v.ViewHeight} viewxy=({v.ViewX},{v.ViewY}) port={v.PortWidth}x{v.PortHeight} portxy=({v.PortX},{v.PortY})");
    }
}
