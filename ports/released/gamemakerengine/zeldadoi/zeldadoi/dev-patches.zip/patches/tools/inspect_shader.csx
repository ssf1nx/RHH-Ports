using System;
using UndertaleModLib;
using UndertaleModLib.Models;

EnsureDataLoaded();

foreach (var shd in Data.Shaders)
{
    if (shd?.Name?.Content != "shd_CRT") continue;

    Console.WriteLine("=== shd_CRT vertex (GLSL ES) ===");
    Console.WriteLine(shd.GLSL_ES_Vertex?.Content ?? "(null)");
    Console.WriteLine("=== shd_CRT fragment (GLSL ES) ===");
    Console.WriteLine(shd.GLSL_ES_Fragment?.Content ?? "(null)");
    break;
}
